package dar.games.music.capstonekote.ui.game;

public interface OnGameFragInteractionListener {
        void onRoundFinished();
        void onReadyClicked();
        void onPlayAgain();
        void onMainMenu();
}
