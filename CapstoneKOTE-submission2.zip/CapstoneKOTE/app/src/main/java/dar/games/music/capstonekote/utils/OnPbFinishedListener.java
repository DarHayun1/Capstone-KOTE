package dar.games.music.capstonekote.utils;

public interface OnPbFinishedListener {
    void onFinished();
}
